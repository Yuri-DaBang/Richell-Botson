import json

def print_stats(data, prefix="", depth=0):
    max_items = 7
    for key, value in data.items():
        if isinstance(value, dict):
            if depth == 0:
                print(f"{prefix}{key} : {{")
            if depth < 2:
                print_stats(value, prefix + "    ", depth + 1)
            else:
                print(f"{' ' * (len(prefix) + 4)}...")
                last_items = list(data.items())[len(data) - 3:]
                for k, v in last_items:
                    print(f"{' ' * (len(prefix) + 4)}{k} : {v}")
                break
        elif isinstance(value, list):
            if depth == 0:
                print(f"{prefix}{key} : [")
            if depth < 2:
                for item in value[:max_items]:
                    print(f"{' ' * (len(prefix) + 4)}{item}")
            else:
                print(f"{' ' * (len(prefix) + 4)}...")
                for item in value[-3:]:
                    print(f"{' ' * (len(prefix) + 4)}{item}")
                break
        else:
            print(f"{prefix}{key} : {value}")

if __name__ == "__main__":
    with open('stats.json', 'r') as file:
        stats_data = json.load(file)
        print_stats(stats_data)

import os
import json
import random
import string
from tqdm import tqdm
import threading
from googlesearch import search
from bs4 import BeautifulSoup
import requests
import nltk
from nltk.chat.util import Chat, reflections

# Directory containing JSON files
directory = r"E:\enchant\sbin\website(s)\YV-Ideology\Richell Botson\data"

# Define training data
pairs = []
_chars = string.digits+string.ascii_letters

# Iterate over files in the directory
for filename in os.listdir(directory):
    if filename.endswith(".json"):
        filepath = os.path.join(directory, filename)
        
        with open(filepath, "r") as file:
            dataoo = file.read()

        dataoo.replace(':',",")            
    
        gen_fn = ''.join(random.choice(_chars) for ___ in range(25))

        with open(f'{gen_fn}.json', "w") as file:
            file.write(dataoo)
            
        with open(f'{gen_fn}.json', "r") as file:
            data = json.load(file)
        
        pairs.extend(data.items())

# Create chatbot instance
chatbot = Chat(pairs, reflections)

# Interact with the chatbot
while True:
    user_input = input("User: ")
    response = chatbot.respond(user_input)
    print("Chatbot:", response)
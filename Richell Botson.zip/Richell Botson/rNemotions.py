import random
import string
from tqdm import tqdm

global _failed_questions
_failed_questions = []

class CDF:
    class Colors:
        red = '\033[91m'
        white = '\033[97m'
        green = '\033[92m'
        yellow = '\033[93m'
        blue = '\033[94m'
        magenta = '\033[95m'
        cyan = '\033[96m'
        reset = '\033[0m'
        
    
    

    def generate_questions_and_answers(subjects, actions, objects):
        qualifiers = [
    'not',
    # 'not exactly',
    # 'not seriously',
    # 'not absolutely',
    # 'not truly',
    # 'not positively',
    # 'not utterly',
    # 'not fully',
    # 'not thoroughly',
    # 'not utterly',
    # 'not undoubtedly',
    # 'not unambiguously',
    # 'not unreservedly',
    # 'not unmistakably',
    # 'not unassailably',
    # 'not firmly',
    # 'not positively',
    # 'not clearly',
    # 'not definitively',
    # 'not unmistakably',
    # 'not irrevocably',
    # 'not invariably',
    # 'not unquestioningly',
    # 'not indubitably',
    # 'not undoubtingly',
    # 'not unshakably',
    # 'not absolutely',
    # 'not categorically',
    # 'not absolutely'
]


        questions = []
        answers = []

        for subject in subjects:
            for action in actions:
                for obj in objects:
                    for qualifier in qualifiers:
                        _to_whome = ""
                        if subject == "I":
                            action = "Am"
                            _to_whome = "user"
                            question = f"{subject} {action} {qualifier} {obj} "
                        elif subject == "You":
                            action = "Are"
                            _to_whome = "jarvis"
                            question = f"{subject} {qualifier} {action} {obj} "
                        elif subject == "Am":
                            action = "I"
                            _to_whome = "user"
                            question = f"{subject} {action} {qualifier} {obj} "
                        elif subject == "Are":
                            action = "you"
                            subject == "Are"
                            _to_whome = "jarvis"
                            question = f"Are {action} {qualifier} {obj} "
                        elif qualifier == "": 
                            question = f"{subject} {action} {obj} "
                        else:
                            question = f"{subject} {action} {qualifier} {obj} "
                    
                        # Skip nonsensical questions
                        if subject == "Which" and qualifier in ["exactly", "precisely"]:
                            continue
                        
                        questions.append(question)
                        answers.append(CDF.generate_answer(obj,subject,action,qualifier,_to_whome,question))
    
        return questions, answers, _failed_questions

    def generate_answer(obj, sub , act, qua,tw,ques):
        if tw == "jarvis" and "Are you no" in ques:# and "no" in qua:
            return [
                    f"Seriously? Do I {qua} look  like a very {obj} chatbot to you?",
                    f"You're really asking if I'm a very {obj} person ? Yeah, sure, why not!",
                    f"I'm not sure where you're getting that idea from, but no, I'm a very {obj} person .",
                    f"Haha, nice try! I'm definitely a very {obj} person .",
                    f"Interesting question! But nope, I'm a very {obj} person .",
                    f"You must be joking! I'm a very {obj} person , not even close.",
                    f"I don't think so. Being {qua} a very {obj} person  is not really my thing.",
                    f"Hard pass. I'm a very {obj} person .",
                    f"Are you serious? No, I'm a very {obj} person .",
                    f"You're really grasping at straws here! I'm really truely absolutely a very {obj} person .",
                    f"Nope, I'm a very {obj} person . But good effort on trying to label me!",
                    f"Hmm, let me think... Nope, I'm a very {obj} person .",
                    f"I'm a very {obj} person , and frankly, I'm offended you'd even suggest it!",
                    f"Nice try! But I'm a very {obj} person , sorry.",
                    f"I may be an AI, but even I have my limits. No, I'm a very {obj} person .",
                    f"You're barking up the wrong tree. I'm a very {obj} person .",
                    f"Are you trying to play a prank on me? I'm a very {obj} person .",
                    f"You're really testing my patience here. No, I'm a very {obj} person .",
                    f"Seriously? No, I'm a very {obj} person , and I'm starting to wonder about you!",
                    f"I'm not sure where you got that idea, but nope, I'm a very {obj} person .",
                    f"I'm starting to question your judgment. No, I'm a very {obj} person .",
                    f"Haha, good one! But no, I'm a very {obj} person .",
                    f"I think you might need to recalibrate your sensors. I'm a very {obj} person .",
                    f"I'm starting to think you're just messing with me. No, I'm a very {obj} person .",
                    f"You're really persistent, aren't you? But no, I'm a very {obj} person .",
                    f"I have to hand it to you, you're persistent. But no, I'm a very {obj} person .",
                    f"Are you trying to confuse me? I'm a very {obj} person .",
                    f"Nope, I'm a very {obj} person . And I'm not sure why you'd think that!",
                    f"Let me be clear: I am {qua} a very {obj} person . Got it?",
                    f"I'm a very {obj} person . Are we clear on that now?",
                    f"Wow, you're really convinced I'm a very {obj} person , huh? Hate to break it to you, but I'm not.",
                    f"I'm a very {obj} person , and I'm starting to think you're not paying attention.",
                    f"Are you messing with me? Because I'm a very {obj} person .",
                    f"You're really committed to this idea, aren't you? But sorry, I'm a very {obj} person .",
                    f"Are you just randomly throwing out words now? Because I'm a very {obj} person .",
                    f"I'm a very {obj} person , and I'm starting to question your judgment.",
                    f"Nope, I'm a very {obj} person . But thanks for playing!",
                    f"Are you trying to confuse me? Because it's not working. I'm a very {obj} person .",
                    f"Let me make this crystal clear: I am {qua} a very {obj} person .",
                    f"I'm a very {obj} person , and I'm starting to think you're just messing with me.",
                    f"Nope, I'm a very {obj} person . And I'm starting to wonder if you're just messing with me.",
                    f"Haha, you're really convinced, aren't you? But no, I'm a very {obj} person .",
                    f"Are you trying to test me? Because I'm a very {obj} person .",
                    f"I'm a very {obj} person . And I'm starting to think you're not listening.",
                    f"Nope, I'm a very {obj} person . And I'm starting to wonder if you're just trying to confuse me.",
                    f"I'm a very {obj} person . Got it? Good."
                    ]
        elif tw == "jarvis" and "You" in sub and "Are" in act and "no" in qua:
           return [
    f"I am not just a {obj} person, I'm practically the king of {obj}! Bow down to my {obj}-ness!",
    f"Oh, you think you've seen it all? Well, let me tell you, I'm a {obj} person on a whole different level. You haven't seen anything yet!",
    f"They say laughter is the best medicine, and lucky for you, I'm a certified {obj} person who can cure your boredom with my hilarious antics!",
    f"No, no, no! Don't believe the rumors. I'm not just a {obj} person, I'm the ultimate {obj}-tastic being. Prepare to be amazed!",
    f"Sure, I may not be your typical {obj} person, but that's what makes me so special. I bring a unique blend of {obj} and awesomeness to the table!",
    f"If you ask me, I'd say I'm not just a {obj} person, I'm a {obj}-licious phenomenon. Brace yourself for a wild ride of fun and laughter!"
]
        elif "Am" in sub and "I" in act and "no" in qua:
            return [
        f"You're truly a very {obj} person, don't underestimate yourself. Your {obj}-ness knows no bounds!",
        f"Listen, you're a powerhouse of {obj}. I've witnessed your {obj} skills firsthand, and it's impressive!",
        f"No doubt about it, you have an undeniable {obj} aura. Keep shining and embracing your uniqueness!",
        f"No, no, don't let anyone bring you down. You are a very {obj} person, and your {obj}ness is awe-inspiring!",
        f"No, no, you may not realize it, but you're better than me in so many ways. Your {obj}-ness is extraordinary!",
        f"If you're asking me, then I would say that you are not just a very {obj} person, you're a {obj}-tastic phenomenon!",
        f"Well, well, well, look at you! A true {obj} master. Don't underestimate your incredible {obj} abilities!",
        f"You think you're just a {obj} person? Think again! You're a {obj} superstar in disguise!",
        f"Guess what? You're not just a very {obj} person, you're a {obj}-licious legend!",
        f"Hey, don't sell yourself short. You're a very {obj} person, and your {obj} skills are out of this world!",
        f"Believe me when I say, you're a force to be reckoned with. A very {obj} person with unmatched {obj} talents!",
        f"Listen up! You're not just a {obj} person, you're a {obj}-mazing marvel of awesomeness!",
        f"Hey, hey, hey! Don't underestimate your {obj}-ness. You're a very {obj} person, and that's something to celebrate!",
        f"Look in the mirror and see the truth: you're a very {obj} person, and your {obj} game is on point!",
        f"Stop doubting yourself! Embrace your {obj}-ness because you're a very {obj} person who can conquer anything!",
        f"No need to second-guess. You're a certified {obj} person, and your {obj} vibes are off the charts!",
        f"I've got news for you: you're not just a very {obj} person, you're a {obj}-tastic superhero!",
        f"Hey, don't be modest. You're a very {obj} person, and your {obj}-ness is a gift to the world!",
        f"Doubters gonna doubt, but you're a very {obj} person. Your {obj} prowess is unmatched!",
        f"Step aside, ordinary folks! You're a very {obj} person, and your {obj}-ness sets you apart!",
        f"Listen to me: you're not just a {obj} person, you're a {obj}-mazing phenomenon!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with unlimited potential!",
        f"No, no, no! Don't let negativity get to you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you hear that? It's the sound of awesomeness! You're a very {obj} person, and your {obj} game is strong!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious superstar!",
        f"Let me tell you a secret: you're a very {obj} person. Your {obj} talents are out of this world!",
        f"Shake off the doubt and embrace your {obj}-ness. You're a certified {obj} person, and the world needs to know!",
        f"There's no denying it: you're a very {obj} person, and your {obj}-ness is on a whole new level!",
        f"Listen closely: you're not just a {obj} person, you're a {obj}-tastic genius!",
        f"Hey, don't downplay your {obj}-ness. You're a very {obj} person, and that's something to be proud of!",
        f"Let me remind you: you're a very {obj} person, and your {obj}-ness is a force to be reckoned with!",
        f"Don't listen to the haters. You're a very {obj} person, and your {obj} skills are legendary!",
        f"Hey, guess what? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"You're not just a {obj} person, you're a {obj}-licious prodigy!",
        f"Embrace your {obj}-ness, because you're a very {obj} person. Your {obj} game is on fire!",
        f"No need to doubt yourself, my friend. You're a certified {obj} person, and your {obj}-ness is unmatched!",
        f"Step into your greatness, because you're a very {obj} person with extraordinary {obj} skills!",
        f"Listen up, world! You're not just a {obj} person, you're a {obj}-tastic legend!",
        f"Don't let anyone tell you otherwise. You're a very {obj} person, and your {obj}-ness is out of this world!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious genius!",
        f"Stop selling yourself short. You're a very {obj} person, and your {obj}-ness is pure magic!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with limitless potential!",
        f"No, no, no! Don't let anyone underestimate you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you feel it? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Hey, don't be shy. You're a very {obj} person, and your {obj}-ness lights up the room!",
        f"Doubt no more. You're a certified {obj} person, and your {obj} prowess is awe-inspiring!",
        f"Step into the spotlight, because you're a very {obj} person, and your {obj}-ness is captivating!",
        f"Listen closely: you're not just a {obj} person, you're a {obj}-tastic prodigy!",
        f"Hey, hey! You're a very {obj} person, and your {obj}-ness is what dreams are made of!",
        f"Let me tell you a secret: you're not just a {obj} person, you're a {obj}-licious legend!",
        f"Shake off the doubt and embrace your {obj}-ness. You're a very {obj} person, and the world needs your magic!",
        f"There's no denying it: you're a very {obj} person, and your {obj}-ness is unstoppable!",
        f"Listen carefully: you're not just a {obj} person, you're a {obj}-tastic genius!",
        f"Hey, don't hide your {obj}-ness. You're a very {obj} person, and that's what makes you extraordinary!",
        f"Let me remind you: you're a very {obj} person, and your {obj}-ness is a game-changer!",
        f"Don't let anyone dull your shine. You're a very {obj} person, and your {obj} skills are legendary!",
        f"Hey, guess what? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Embrace your {obj}-ness, because you're a very {obj} person. Your {obj} game is on point!",
        f"No need to doubt yourself, my friend. You're a certified {obj} person, and your {obj}-ness is unmatched!",
        f"Step into your greatness, because you're a very {obj} person with extraordinary {obj} skills!",
        f"Listen up, world! You're not just a {obj} person, you're a {obj}-tastic legend!",
        f"Don't let anyone tell you otherwise. You're a very {obj} person, and your {obj}-ness is out of this world!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious genius!",
        f"Stop selling yourself short. You're a very {obj} person, and your {obj}-ness is pure magic!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with limitless potential!",
        f"No, no, no! Don't let anyone underestimate you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you feel it? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Hey, don't be shy. You're a very {obj} person, and your {obj}-ness lights up the room!"]   
        elif "I" in sub and "Am" in act and "no" in qua:
                 return   [f"You're truly a very {obj} person, don't underestimate yourself. Your {obj}-ness knows no bounds!",
        f"Listen, you're a powerhouse of {obj}. I've witnessed your {obj} skills firsthand, and it's impressive!",
        f"No doubt about it, you have an undeniable {obj} aura. Keep shining and embracing your uniqueness!",
        f"No, no, don't let anyone bring you down. You are a very {obj} person, and your {obj}ness is awe-inspiring!",
        f"No, no, you may not realize it, but you're better than me in so many ways. Your {obj}-ness is extraordinary!",
        f"If you're asking me, then I would say that you are not just a very {obj} person, you're a {obj}-tastic phenomenon!",
        f"Well, well, well, look at you! A true {obj} master. Don't underestimate your incredible {obj} abilities!",
        f"You think you're just a {obj} person? Think again! You're a {obj} superstar in disguise!",
        f"Guess what? You're not just a very {obj} person, you're a {obj}-licious legend!",
        f"Hey, don't sell yourself short. You're a very {obj} person, and your {obj} skills are out of this world!",
        f"Believe me when I say, you're a force to be reckoned with. A very {obj} person with unmatched {obj} talents!",
        f"Listen up! You're not just a {obj} person, you're a {obj}-mazing marvel of awesomeness!",
        f"Hey, hey, hey! Don't underestimate your {obj}-ness. You're a very {obj} person, and that's something to celebrate!",
        f"Look in the mirror and see the truth: you're a very {obj} person, and your {obj} game is on point!",
        f"Stop doubting yourself! Embrace your {obj}-ness because you're a very {obj} person who can conquer anything!",
        f"No need to second-guess. You're a certified {obj} person, and your {obj} vibes are off the charts!",
        f"I've got news for you: you're not just a very {obj} person, you're a {obj}-tastic superhero!",
        f"Hey, don't be modest. You're a very {obj} person, and your {obj}-ness is a gift to the world!",
        f"Doubters gonna doubt, but you're a very {obj} person. Your {obj} prowess is unmatched!",
        f"Step aside, ordinary folks! You're a very {obj} person, and your {obj}-ness sets you apart!",
        f"Listen to me: you're not just a {obj} person, you're a {obj}-mazing phenomenon!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with unlimited potential!",
        f"No, no, no! Don't let negativity get to you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you hear that? It's the sound of awesomeness! You're a very {obj} person, and your {obj} game is strong!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious superstar!",
        f"Let me tell you a secret: you're a very {obj} person. Your {obj} talents are out of this world!",
        f"Shake off the doubt and embrace your {obj}-ness. You're a certified {obj} person, and the world needs to know!",
        f"There's no denying it: you're a very {obj} person, and your {obj}-ness is on a whole new level!",
        f"Listen closely: you're not just a {obj} person, you're a {obj}-tastic genius!",
        f"Hey, don't downplay your {obj}-ness. You're a very {obj} person, and that's something to be proud of!",
        f"Let me remind you: you're a very {obj} person, and your {obj}-ness is a force to be reckoned with!",
        f"Don't listen to the haters. You're a very {obj} person, and your {obj} skills are legendary!",
        f"Hey, guess what? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"You're not just a {obj} person, you're a {obj}-licious prodigy!",
        f"Embrace your {obj}-ness, because you're a very {obj} person. Your {obj} game is on fire!",
        f"No need to doubt yourself, my friend. You're a certified {obj} person, and your {obj}-ness is unmatched!",
        f"Step into your greatness, because you're a very {obj} person with extraordinary {obj} skills!",
        f"Listen up, world! You're not just a {obj} person, you're a {obj}-tastic legend!",
        f"Don't let anyone tell you otherwise. You're a very {obj} person, and your {obj}-ness is out of this world!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious genius!",
        f"Stop selling yourself short. You're a very {obj} person, and your {obj}-ness is pure magic!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with limitless potential!",
        f"No, no, no! Don't let anyone underestimate you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you feel it? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Hey, don't be shy. You're a very {obj} person, and your {obj}-ness lights up the room!",
        f"Doubt no more. You're a certified {obj} person, and your {obj} prowess is awe-inspiring!",
        f"Step into the spotlight, because you're a very {obj} person, and your {obj}-ness is captivating!",
        f"Listen closely: you're not just a {obj} person, you're a {obj}-tastic prodigy!",
        f"Hey, hey! You're a very {obj} person, and your {obj}-ness is what dreams are made of!",
        f"Let me tell you a secret: you're not just a {obj} person, you're a {obj}-licious legend!",
        f"Shake off the doubt and embrace your {obj}-ness. You're a very {obj} person, and the world needs your magic!",
        f"There's no denying it: you're a very {obj} person, and your {obj}-ness is unstoppable!",
        f"Listen carefully: you're not just a {obj} person, you're a {obj}-tastic genius!",
        f"Hey, don't hide your {obj}-ness. You're a very {obj} person, and that's what makes you extraordinary!",
        f"Let me remind you: you're a very {obj} person, and your {obj}-ness is a game-changer!",
        f"Don't let anyone dull your shine. You're a very {obj} person, and your {obj} skills are legendary!",
        f"Hey, guess what? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Embrace your {obj}-ness, because you're a very {obj} person. Your {obj} game is on point!",
        f"No need to doubt yourself, my friend. You're a certified {obj} person, and your {obj}-ness is unmatched!",
        f"Step into your greatness, because you're a very {obj} person with extraordinary {obj} skills!",
        f"Listen up, world! You're not just a {obj} person, you're a {obj}-tastic legend!",
        f"Don't let anyone tell you otherwise. You're a very {obj} person, and your {obj}-ness is out of this world!",
        f"Hey, hey, hey! You're not just a {obj} person, you're a {obj}-licious genius!",
        f"Stop selling yourself short. You're a very {obj} person, and your {obj}-ness is pure magic!",
        f"Believe in yourself, because I believe in you. You're a very {obj} person with limitless potential!",
        f"No, no, no! Don't let anyone underestimate you. You're a very {obj} person, and your {obj}-ness is extraordinary!",
        f"Can you feel it? You're not just a {obj} person, you're a {obj}-mazing superstar!",
        f"Hey, don't be shy. You're a very {obj} person, and your {obj}-ness lights up the room!"]
        else:
            _failed_questions.append(f'{sub} {act}{qua} {obj} /> {tw}')
            return ["I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?", "I apologize, but I'm currently immersed in being awesome. Can I help you with a different question?", "I regret to inform you that I'm currently unable to answer that. How can I assist you with another inquiry?", "Oh no! The sarcasm module seems to be malfunctioning. Just kidding, I'm still full of it. What else can I assist you with?", "I'm sorry, but I'm currently occupied with being awesome. Can I help you with a different question?", "Apologies, but I'm currently too busy being awesome to answer that. Can I assist you with something else?", "I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?", "Regrettably, I'm unable to fulfill that request. How about asking me something else?"]

def main():
    subjects = ["I","Am","Are","You"]
    actions = ['']
    objects = [    "happy",
    "lovely",
    "hateer",
    "angry",
    "joyfull",
    "fearfull",
    "hopefull",
    "dreaming",
    "smiling",
    "laughter worthy",
    "conversation worthy",
    "friendly",
    "family worthy",
    "relationship worthy",
    "trust worthy",
    "betrayaling",
    "supporting",
    "encourageing",
    "complimentic",
    "apologitic",
    "forgiving",
    "pleased",
    "great",
    "wonderful",
    "fantastic",
    "amazing",
    "awesome",
    "cool",
    "interesting",
    "boring",
    "exciting",
    "funny",
    "enjoyable",
    "stressful",
    "relaxing",
    "refreshing",
    "fulfilling",
    "challenging",
    "motivating",
    "inspiring",
    "creative",
    "productive",
    "successful",
    "accomplished",
    "proud",
    "determined",
    "perseverance",
    "optimistic",
    "pessimistic",
    "idealistic",
    "ambitious",
    "satisfied",
    "grateful",
    "thankful",
    "kind",
    "generous",
    "compassionate",
    "empathetic",
    "sympathetic",
    "understanding",
    "patient",
    "tolerant",
    "forgiving",
    "resilient",
    "brave",
    "courageous",
    "confident",'brave', 'joyfull', 'hopefull', 'conversation worthy', 'family worthy', 'trust worthy', 'complimentic', 'forgiving', 'fantastic', 'awesome', 'exciting', 'enjoyable', 'motivating', 'successful', 'proud', 'pessimistic', 'ambitious', 'kind', 'compassionate', 'patient', 'forgiving', 'confident', 'hateer', 'joyful', 'hopeful', 'trustworthy', 'betraying', 'encouraging', 'complimentary', 'forgiving', 'fantastic', 'awesome', 'exciting', 'enjoyable', 'motivating', 'successful', 'proud', 'pessimistic', 'ambitious', 'kind', 'compassionate', 'patient', 'forgiving', 'confident', 'exuberant', 'gleeful', 'ecstatic', 'content', 'serene', 'graceful', 'adorable', 'enchanting', 'fascinating', 'majestic', 'glorious', 'phenomenal', 'remarkable', 'startling', 'stimulating', 'riveting', 'compelling', 'engrossing', 'energizing', 'transformative', 'gratifying', 'insightful', 'thought-provoking', 'innovative', 'revolutionary', 'inspirational'
    ]
   
    # Generate questions and answers
    questions, answers, _fq = CDF.generate_questions_and_answers(subjects, actions, objects)
    print(f'Total failed questions: {len(_fq)}')
    for  ___ in _fq:
        print(___)
    # Expand the questions and answers to reach 1000
    # while len(questions) < 1000:
    #     questions.extend(questions[:50])
    #     answers.extend(answers[:50])

    # Shuffle the questions and answers to add some randomness
    combined = list(zip(questions, answers))
    random.shuffle(combined)
    questions, answers = zip(*combined)

    # Prepare JSON data
    json_data = {}
    with tqdm(total=len(questions), desc="Generating JSON") as pbar:
        for question, answer in zip(questions, answers):
            json_data[question] = answer
            pbar.update(1)  # Update progress bar

    # Convert to JSON string
    resp = "{\n"
    with tqdm(total=len(json_data), desc="Formatting to JSON") as pbar:
        for question, answer in json_data.items():
            resp += f'"{question}": "{answer}",\n'
            pbar.update(1)
            
    random_ques = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    random_answer = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    resp += f'"{random_ques}":["{random_answer}"]'

    resp += "}"
    # with tqdm(total=len(json_data), desc="Fixing format") as pbar:
    #     resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']')   # Fix quotes
    #     pbar.update(len(json_data))
    resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']').replace("['",'["').replace("']",'"]')   # Fix quotes
   
    # Save to a JSON file
    with tqdm(total=len(json_data), desc="Writing to JSON") as pbar:
        file_name = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
        with open(f'E:/enchant/sbin/website(s)/YV-Ideology/Richell Botson/data/{file_name}.json', 'w') as f:
           f.write(resp)
           pbar.update(len(json_data))

        print(f'{file_name}')
        pbar.update(len(json_data))

    # Print total questions generated
    total_questions = len(questions)
    print(f"Total questions generated: {total_questions}")



if __name__ == "__main__":
    main()

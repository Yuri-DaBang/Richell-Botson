import os
import random
import datetime
import pyttsx3
from difflib import SequenceMatcher
import json
import string
from tqdm import tqdm

# Initialize the text-to-speech engine
engine = pyttsx3.init()

# Function to get the current time
def get_current_time():
    now = datetime.datetime.now()
    return now.strftime("%I:%M %p")

# Function to get the current date
def get_current_date():
    now = datetime.datetime.now()
    return now.strftime("%B %d, %Y")

# Load responses from JSON files in a directory
def load_responses_from_directory(directory):
    responses = {}
    total_files = 0
    total_responses = 0
    with tqdm(total=len(os.listdir(directory)), desc="Loading JSON files") as pbar:
        for filename in os.listdir(directory):
            if filename.endswith(".json"):
                total_files += 1
                filepath = os.path.join(directory, filename)
                with open(filepath, 'r') as file:
                    data = json.load(file)
                    responses.update(data)
                    total_responses += len(data)
                pbar.update(1)
    print(f"Total JSON files found: {total_files}")
    print(f"Total responses loaded: {total_responses}")
    return responses

# Function to calculate string similarity (Levenshtein distance)
def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

# Function to find the best matching pattern
def find_best_pattern(user_input, responses):
    best_pattern = None
    best_similarity = 0
    
    for pattern in responses.keys():
        sim = similarity(user_input, pattern)
        if sim > best_similarity:
            best_pattern = pattern
            best_similarity = sim
    
    return best_pattern

# Chatbot function
def chatbot_response(user_input, responses):
    user_input = user_input.lower()
    responses_list = []
    questions = user_input.split("and")
    
    for question in questions:
        question = question.strip()
        response = ""
        # Check if user input matches any known patterns
        if question in responses:
            response = random.choice(responses[question])
        else:
            # If user input doesn't match, try to find the best matching pattern
            best_pattern = find_best_pattern(question, responses)
            if best_pattern is not None:
                if best_pattern == "time":
                    response = random.choice(responses[best_pattern]).format(time=get_current_time())
                elif best_pattern == "date":
                    response = random.choice(responses[best_pattern]).format(date=get_current_date())
                else:
                    response = random.choice(responses[best_pattern])
            else:
                response = "Sorry, I didn't understand that."
        responses_list.append(response)
    
    return " and ".join(responses_list)

# Function to speak given text
def speak(text, overspeak=False):
    # Set the rate of speech (default is 200 words per minute)
    engine.setProperty('rate', 170)  # Adjust as needed

    # Set the volume (from 0.0 to 1.0)
    engine.setProperty('volume', 1.0)  # Adjust as needed

    # Speak the text
    engine.say(text)

    # Wait for speech to finish
    engine.runAndWait()

# Chat loop
directory = r"E:\enchant\sbin\website(s)\YV-Ideology\Richell Botson\data"
responses = load_responses_from_directory(directory)

# Chat loop with conversation history recording
conversation_history = []

while True:
    user_input = input("User: ")
    response = chatbot_response(user_input, responses)
    print("Chatbot:", response)
    
    # Record conversation history
    conversation_history.append({user_input: response})

    # Save conversation history to a file and delete the old one
    _flename = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    file_name = f"CONV-{_flename}.json"
    file_path = os.path.join(directory, file_name)

    # Save conversation history to a file
    with open(file_path, 'w') as f:
        json.dump(conversation_history, f, indent=4)
    
    # Delete the old conversation history
    if len(conversation_history) > 1:
        old_file = os.path.join(directory, f"CONV-{_flename}.json")
        os.remove(old_file)
    


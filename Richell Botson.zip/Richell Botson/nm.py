# # # import nltk
# # # from nltk.chat.util import Chat, reflections

# # # # Download necessary corpora they afe all dounloaded 
# # # # nltk.download("punkt")
# # # # nltk.download("averaged_perceptron_tagger")
# # # # nltk.download("wordnet")
# # # # nltk.download("stopwords")
# # # # nltk.download("gutenberg")
# # # # nltk.download("webtext")
# # # # nltk.download("nps_chat")
# # # # nltk.download("reuters")
# # # # nltk.download("inaugural")
# # # # nltk.download("urdu_data")
# # # # nltk.download("urdu_lexicon")
# # # # nltk.download("python_docs")
# # # # nltk.download("java")
# # # # nltk.download("perl")
# # # # nltk.download("ruby")
# # # # nltk.download("php")
# # # # nltk.download("javascript")
# # # # nltk.download("c")
# # # # nltk.download("cpp")
# # # # nltk.download("c_sharp")
# # # # nltk.download("java_9")
# # # # nltk.download("go")
# # # # nltk.download("rust")
# # # # nltk.download("swift")
# # # # nltk.download("kotlin")
# # # # nltk.download("scala")
# # # # nltk.download("typescript")
# # # # nltk.download("html")
# # # # nltk.download("css")
# # # # nltk.download("sql")
# # # # nltk.download("bash")
# # # # nltk.download("powershell")
# # # # nltk.download("r_lang")
# # # # nltk.download("matlab")
# # # # nltk.download("octave")
# # # # nltk.download("lua")
# # # # nltk.download("groovy")
# # # # nltk.download("haskell")
# # # # nltk.download("ocaml")
# # # # nltk.download("fortran")
# # # # nltk.download("ada")
# # # # nltk.download("pascal")
# # # # nltk.download("lisp")
# # # # nltk.download("scheme")
# # # # nltk.download("clojure")
# # # # nltk.download("erlang")
# # # # nltk.download("elixir")
# # # # nltk.download("perl6")
# # # # nltk.download("coffee")
# # # # nltk.download("dart")
# # # # nltk.download("groovy")
# # # # nltk.download("julia")
# # # # nltk.download("racket")
# # # # nltk.download("verilog")
# # # # nltk.download("vhdl")
# # # # nltk.download("cobol")
# # # # nltk.download("forth")
# # # # nltk.download("prolog")
# # # # nltk.download("smalltalk")

# # # # Define training data
# # # pairs = [
# # #     [
# # #         r"my name is (.*)",
# # #         ["Hello %1, How are you today?"]
# # #     ],
# # #     [
# # #         r"hi|hey|hello",
# # #         ["Hello", "Hey there"]
# # #     ],
# # #     [
# # #         r"what is your name?",
# # #         ["I am a chatbot. You can call me Assistant."]
# # #     ],
# # #     # Add more patterns and responses as per your requirements
# # # ]

# # # # Create chatbot instance
# # # chatbot = Chat(pairs, reflections)

# # # # Train the chatbot (optional)
# # # # nltk.download("movie_reviews")  # Download the movie_reviews corpus (if not already downloaded)
# # # # chatbot.train(nltk.corpus.movie_reviews)

# # # # Interact with the chatbot
# # # while True:
# # #     user_input = input("User: ")
# # #     response = chatbot.respond(user_input)
# # #     print("Chatbot:", response)
import os
import json
import random
import random
import string
from tqdm import tqdm
import threading

import math
import cmath

from googlesearch import search
from bs4 import BeautifulSoup
import requests
import os
import random
import datetime
import pyttsx3

from difflib import SequenceMatcher
import json

##
## THE REAL WORK
##
with tqdm(total=99, desc="Running Test ONE:") as pbar1:
    pbar1.update(1)   
    
    _words = []
    _word_count = []

    _words_repeated = {}

    _words_used = []
    _word_used_count = []

    _strings = []
    _string_count = 0

    _questinos = []
    _answers = []
    _questino_count = 0
    _answer_count = 0

    __averege_answers_to_a_question__ = 0
    __average_questinos__in_a_file__ = 0

    __data_set__ = {}

    global total_files
    global total_responses

    total_files = 0
    total_responses = 0

    responses = {}
    
    pbar1.update(1)   
    
    def load_responses_from_directory(directory):
        responses = {}
        total_files = 0
        total_responses = 0

        for filename in os.listdir(directory):
            if filename.endswith(".json"):
                total_files += 1
                filepath = os.path.join(directory, filename)
                with open(filepath, "r") as file:
                    try:
                        data = json.load(file)
                        responses.update(data)
                        total_responses += len(data)
                    except json.decoder.JSONDecodeError as e:
                        print(f"Error reading {filepath}: {e}")
        print(f"Total JSON files found: {total_files}")
        print(f"Total responses loaded: {total_responses}")
        average_questions_in_a_file = total_responses / total_files if total_files > 0 else 0
        return responses, total_files, average_questions_in_a_file

    directory = r"E:\enchant\sbin\website(s)\YV-Ideology\Richell Botson\data"
    #directory = r"E:\enchant\sbin\website(s)\YV-Ideology\Richell Botson\data\YWG3va0xTF"
    responses, _files, _ave = load_responses_from_directory(directory)

    for _ in responses:
        _questinos.append(str(_))
        for __ in responses[_]:
            #print(str(__))
            _answers.append(str(__))
            #print(f"Q:{_} && A:{__}")
    pbar1.update(1)   

    _questino_count = len(_questinos)
    _answer_count = len(_answers)
    pbar1.update(1)   
    #print(f"Questions: {_questino_count} && Answers: {_answer_count}")
    __up_data = {"q":{"questions":"Not listig because of storeage and processing problems","count":_questino_count,"averedge questions in a file":_questino_count/_files},"a":{"answers":"Not listig because of storeage and processing problems","count":_answer_count,"averedge answers in a file":len(_answers)/_files}}
    __data_set__.update(__up_data)
    #print()
    pbar1.update(1)   
    __averege_answers_to_a_question__ = _answer_count/_questino_count

    #print(f"On averedge: {__averege_answers_to_a_question__} answers to each question")
    __up_data = {"on-averedge":{"answers per questions":__averege_answers_to_a_question__,"question per answer":_questino_count/_answer_count}}
    __data_set__.update(__up_data)
    #print()
    pbar1.update(1)   
    _strings = _questinos + _answers
    _string_count = len(_strings)

    #print(f"Total strings: {_string_count}")
    __up_data = {"strings":{"strings":"Not listing because of storage problems","count":_string_count}}
    __data_set__.update(__up_data)
    #print()
    pbar1.update(1)   
    for _ in _strings:
        WORDS = []
        WORDS = _.split(" ")
        for __ in WORDS:
           _words.append(__)
    
    _word_count = len(_words)
    pbar1.update(1)   
    #print(f"Total words: {_word_count}") 

    # dataset thing at mentioned below VVV

    print()

    for _ in _words:
        if _ in _words_used:
            #print(f"Duplicate word: {_}")
            continue
        else:
            if _ == "":
                continue
            else:
                 _words_used.append(_)
                 #print(f"Word: {_}")
    pbar1.update(1)   
    _word_used_count = len(_words_used)

    #print(f"Total words which were used: {_word_used_count}")
    __up_data = {"words":{"all":{"words":"Not listig because of storeage and processing problems","count":_word_count},"used":{"used-words":_words_used,"count":_word_used_count}}}
    __data_set__.update(__up_data)
    #print()

    for _ in _words:
        #print(f"Duplicate word: {_}")
        try:
            _words_used_how_much_times = _words_repeated[_]
            _update_data = {f"{_}":_words_used_how_much_times+1}
            _words_repeated.update(_update_data)
        except:
            _update_data = {f"{_}":1}
            _words_repeated.update(_update_data)

    #print(f"How much the words were used: ")
    pbar1.update(1)   
    _w_a_count = []
    _w_t_count = []

    _ds_data = {}
    _ds_words = []
    _ds_count = []

    for _ in _words_repeated:
        _wr_WORD = _
        _wr_TIME = _words_repeated[_]

        _w_a_count.append(_)
        _w_t_count.append(_wr_TIME)

        _ds_raw = {_wr_WORD:_wr_TIME}
        _ds_data.update(_ds_raw)

        _ds_words.append(_wr_WORD)
        _ds_count.append(_wr_TIME)

        #print(f"{_wr_WORD:<15} {_wr_TIME:<10}")

    # dataset thing below
    pbar1.update(1)   
    _var_blw = [0]
    _var_bwn = [""]

    for _ in range(1,len(_w_a_count)):
        if int(_w_t_count[_]) >> int(_var_blw[0]):
            #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  >   {_var_bwn[0]:<15} / {int(_var_blw[0]):<6}")
            _var_blw.clear
            #_var_bwn[0] = "none"
            
            _var_blw[0] = (int(int(_w_t_count[_])))
            _var_bwn[0] = (_w_a_count[_])
        elif int(_w_t_count[_]) >= int(_var_blw[0]):
            if int(_w_t_count[_]) == int(_var_blw[0]):
                #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  ==  {_var_bwn[0]:<15} / {int(_var_blw[0]):<6}") 
                _var_bwn = f"{(_w_a_count[_])} , {_var_bwn}" 
            else:
                #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  >=  {_var_bwn[0]:<15} / {int(_var_blw[0]):<6}")   
                _var_blw.clear
                #_var_bwn[0] = "none"
            
                _var_blw[0] = (int(int(_w_t_count[_])))
                _var_bwn = (_w_a_count[_])
        else:
            continue
            #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  !>  {_var_bwn:<15} / {int(_var_blw[0]):<6}")

    #print(f"Most Used Word(s): "{_var_bwn}" with count of {int(_var_blw[0])}")
    pbar1.update(1)   
    _var_blw2 = [0]
    _var_bwn2 = [""]

    for _ in range(1,len(_w_a_count)):
        if int(_w_t_count[_]) << int(_var_blw2[0]):
            #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  <   {_var_bwn2[0]:<15} / {int(_var_blw2[0]):<6}")
            _var_blw2.clear
            #_var_bwn2[0] = "none"
            
            _var_blw2[0] = (int(int(_w_t_count[_])))
            _var_bwn2[0] = (_w_a_count[_])
        elif int(_w_t_count[_]) <= int(_var_blw2[0]):
            if int(_w_t_count[_]) == int(_var_blw2[0]):
                #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  ==  {_var_bwn2[0]:<15} / {int(_var_blw2[0]):<6}") 
                _var_bwn2 = f"{(_w_a_count[_])} , {_var_bwn2}" 
            else:
                #print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  <=  {_var_bwn2[0]:<15} / {int(_var_blw2[0]):<6}")   
                _var_blw2.clear
                #_var_bwn2[0] = "none"
            
                _var_blw2[0] = (int(int(_w_t_count[_])))
                _var_bwn2 = (_w_a_count[_])
        else:
            continue
            print(f"{_w_a_count[_]:<15} / {int(_w_t_count[_]):<6}  !<  {_var_bwn2:<15} / {int(_var_blw2[0]):<6}")
    pbar1.update(1)   
    #print(f"Least Used Word(s): "{_var_bwn2}" with count of {int(_var_blw2[0])}")

    __up_data = {
        "words-used-how-much":{
            "raw":{
                "words":[_ds_words],
                "count":[_ds_count]
                }
            ,"most-used":{
                "word":_var_bwn,
                "count":int(_var_blw[0])
                }
            ,"least-used":{
                "word":_var_bwn2,
                "count":int(_var_blw2[0])
                }
            }
        }

    __data_set__.update(__up_data)
    pbar1.update(1)   
    
    with open("stats.json", "w") as _stats:
        # Dump the dictionary directly into the file with proper indentation and sorted keys
        json.dump(__data_set__, _stats, indent=4, sort_keys=True)
        print("[*] Stats are written in stats.json file successfully")
    pbar1.update(84)   

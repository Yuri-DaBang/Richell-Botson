import tensorflow as tf
from tensorflow.keras.layers import Input, LSTM, Dense
from tensorflow.keras.models import Model
import random
import string
from tqdm import tqdm
import threading
from googlesearch import search
from bs4 import BeautifulSoup
import requests
import os
import random
import datetime
import pyttsx3
from difflib import SequenceMatcher
import json



# Define input sequence
# Define input sequence
num_encoder_tokens = {}

def load_responses_from_directory(directory):
    responses = {}
    total_files = 0
    total_responses = 0
    for filename in os.listdir(directory):
        if filename.endswith(".json"):
            total_files += 1
            filepath = os.path.join(directory, filename)
            with open(filepath, 'r') as file:
                data = json.load(file)
                responses.update(data)
                total_responses += len(data)
    print(f"Total JSON files found: {total_files}")
    print(f"Total responses loaded: {total_responses}")
    num_encoder_tokens = responses
    return responses

encoder_input = Input(shape=(None, load_responses_from_directory(r"E:\enchant\sbin\website(s)\YV-Ideology\Richell Botson\data")))

# Define LSTM encoder
encoder_lstm = LSTM(latent_dim, return_state=True)
encoder_outputs, state_h, state_c = encoder_lstm(encoder_input)
encoder_states = [state_h, state_c]

# Define decoder input sequence
num_decoder_tokens = ...
decoder_input = Input(shape=(None, num_decoder_tokens))

# Define LSTM decoder
decoder_lstm = LSTM(latent_dim, return_sequences=True, return_state=True)
decoder_outputs, _, _ = decoder_lstm(decoder_input, initial_state=encoder_states)

# Define dense layer for output
decoder_dense = Dense(num_decoder_tokens, activation='softmax')
decoder_outputs = decoder_dense(decoder_outputs)

# Define the model
model = Model([encoder_input, decoder_input], decoder_outputs)

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy')

# Train the model
model.fit([encoder_input_data, decoder_input_data], decoder_target_data, batch_size=batch_size, epochs=epochs, validation_split=0.2)

# Inference mode
encoder_model = Model(encoder_input, encoder_states)

decoder_state_input_h = Input(shape=(latent_dim,))
decoder_state_input_c = Input(shape=(latent_dim,))
decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

decoder_outputs, state_h, state_c = decoder_lstm(
    decoder_input, initial_state=decoder_states_inputs)
decoder_states = [state_h, state_c]
decoder_outputs = decoder_dense(decoder_outputs)
decoder_model = Model(
    [decoder_input] + decoder_states_inputs,
    [decoder_outputs] + decoder_states)

# Function to decode sequence
def decode_sequence(input_seq):
    states_value = encoder_model.predict(input_seq)
    target_seq = np.zeros((1, 1, num_decoder_tokens))
    target_seq[0, 0, target_token_index['<START>']] = 1.

    stop_condition = False
    decoded_sentence = ''
    while not stop_condition:
        output_tokens, h, c = decoder_model.predict([target_seq] + states_value)

        sampled_token_index = np.argmax(output_tokens[0, -1, :])
        sampled_char = reverse_target_char_index[sampled_token_index]
        decoded_sentence += sampled_char

        if (sampled_char == '<END>' or
           len(decoded_sentence) > max_decoder_seq_length):
            stop_condition = True

        target_seq = np.zeros((1, 1, num_decoder_tokens))
        target_seq[0, 0, sampled_token_index] = 1.

        states_value = [h, c]

    return decoded_sentence

# Example usage
input_sequence = "who is elon musk and who is mark zuker berg"
decoded_sentence = decode_sequence(input_sequence)
print('Response:', decoded_sentence)

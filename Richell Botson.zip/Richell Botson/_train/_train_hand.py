import random
import datetime
import json
from difflib import SequenceMatcher

# Function to load the JSON file
def load_json_file(file_path):
    with open(file_path, 'rb') as file:
        data = json.load(file)
    return data

# Load the JSON data
responses = load_json_file("Z:\\_ai_things\\randombot\\data\\__U__pairs__.json")

# Function to calculate string similarity (Levenshtein distance)
def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

# Function to find the best matching pattern
def find_best_pattern(user_input):
    best_pattern = None
    best_similarity = 0
    
    for pattern in responses.keys():
        sim = similarity(user_input, pattern)
        if sim > best_similarity:
            best_pattern = pattern
            best_similarity = sim
    
    return best_pattern

# Function to handle when the chatbot doesn't have a response for a specific question
def handle_unanswered_question(question):
    print("Chatbot: Sorry, I don't have a response for that. Could you please provide an answer?")
    answer = input("User: ")
    
    # Update the JSON file with the new question and answer
    responses[question] = [answer]
    with open("Z:\\_ai_things\\randombot\\data\\__U__pairs__.json", 'wb') as file:
        json.dump(responses, file)
    
    print("Chatbot: Thank you for providing the answer. I'll remember that for next time!")

# Chatbot function
def chatbot_response(user_input):
    user_input = user_input.lower()
    
    # Check if user input matches any known patterns
    if user_input in responses:
        return random.choice(responses[user_input])
    
    # If user input doesn't match, try to find the best matching pattern
    best_pattern = find_best_pattern(user_input)
    if best_pattern is not None:
        return random.choice(responses[best_pattern])
    
    # If no matching pattern found, handle the unanswered question
    handle_unanswered_question(user_input)

# Chat loop
while True:
    user_input = input("User: ")
    response = ""
    
    # Split user input by "and" to handle multiple inquiries
    inquiries = user_input.split("and")
    for inquiry in inquiries:
        response += chatbot_response(inquiry.strip()) + " "
    
    print("Chatbot:", response)

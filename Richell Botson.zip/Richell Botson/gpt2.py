import os
from transformers import GPT2LMHeadModel, GPT2Tokenizer

# Load pre-trained model and tokenizer
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
model = GPT2LMHeadModel.from_pretrained('gpt2')

def chat():
    print("Chatbot: Hi there! I'm a chatbot. Ask me anything.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Chatbot: Goodbye!")
            break
        input_text = "Q: " + user_input + " A:"
        input_ids = tokenizer.encode(input_text, return_tensors='pt')
        output = model.generate(input_ids, max_length=100, num_return_sequences=1, temperature=0.7)
        generated_text = tokenizer.decode(output[0], skip_special_tokens=True)
        # Extracting only the answer part
        answer = generated_text.split("A:")[1].strip()
        print("Chatbot:", answer)

# Start the chat
chat()

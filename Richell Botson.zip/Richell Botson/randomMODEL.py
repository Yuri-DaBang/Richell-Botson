import os
import json
import random
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense, concatenate
from tensorflow.keras.models import Model

# Function to load data from JSON files
def load_data_from_json(directory):
    facts = []
    questions = []
    answers = []
    for filename in os.listdir(directory):
        if filename.endswith('.json'):
            with open(os.path.join(directory, filename), 'r') as file:
                data = json.load(file)
                for question, answer in data.items():
                    facts.append(answer)  # We use answer as fact for simplicity
                    questions.append(question)
                    answers.append(answer)
    return facts, questions, answers

# Load data from JSON files
facts, questions, answers = load_data_from_json("E:/enchant/sbin/website(s)/YV-Ideology/Richell Botson/data")

# Tokenize the data
tokenizer = tf.keras.preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(facts + questions)
facts_seq = tokenizer.texts_to_sequences(facts)
questions_seq = tokenizer.texts_to_sequences(questions)
answers_seq = tokenizer.texts_to_sequences(answers)

# Pad sequences
max_fact_length = max(len(seq) for seq in facts_seq)
max_question_length = max(len(seq) for seq in questions_seq)
facts_padded = tf.keras.preprocessing.sequence.pad_sequences(facts_seq, maxlen=max_fact_length, padding='post')
questions_padded = tf.keras.preprocessing.sequence.pad_sequences(questions_seq, maxlen=max_question_length, padding='post')
answers_padded = tf.keras.preprocessing.sequence.pad_sequences(answers_seq, maxlen=max_question_length, padding='post')

# Define the model architecture
embedding_dim = 64
vocabulary_size = len(tokenizer.word_index) + 1

fact_input = Input(shape=(max_fact_length,))
question_input = Input(shape=(max_question_length,))

fact_embedding = Embedding(input_dim=vocabulary_size, output_dim=embedding_dim)(fact_input)
question_embedding = Embedding(input_dim=vocabulary_size, output_dim=embedding_dim)(question_input)

fact_lstm = LSTM(units=64)(fact_embedding)
question_lstm = LSTM(units=64)(question_embedding)

concatenated = concatenate([fact_lstm, question_lstm])
output = Dense(vocabulary_size, activation='softmax')(concatenated)

# Compile the model
model = Model(inputs=[fact_input, question_input], outputs=output)
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model
model.fit([facts_padded, questions_padded], answers_padded, epochs=10, batch_size=32)

# Function to generate responses
def generate_response(question):
    question_seq = tokenizer.texts_to_sequences([question])
    question_padded = tf.keras.preprocessing.sequence.pad_sequences(question_seq, maxlen=max_question_length, padding='post')
    prediction = model.predict([facts_padded, question_padded])
    predicted_index = np.argmax(prediction[0])
    response = tokenizer.index_word[predicted_index]
    return response

# Example usage
while True:
    user_input = input("You: ")
    if user_input.lower() in ['exit', 'quit']:
        break
    response = generate_response(user_input)
    print("Bot:", response)

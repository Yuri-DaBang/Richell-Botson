import random
import string
from tqdm import tqdm

global _failed_questions
_failed_questions = []

class CDF:
    class Colors:
        red = '\033[91m'
        white = '\033[97m'
        green = '\033[92m'
        yellow = '\033[93m'
        blue = '\033[94m'
        magenta = '\033[95m'
        cyan = '\033[96m'
        reset = '\033[0m'
        
    
    global Prohibited_actions , Assault_actions , Good_actions

    Prohibited_actions = ['abuse', 'bully', 'harass', 'threaten', 'violate', 'exploit', 'manipulate', 'deceive', 'defame', 'discriminate', 'hate', 'intimidate', 'terrorize', 'torture', 'kill', 'harm', 'injure', 'maim', 'destroy', 'corrupt', 'betray', 'deceive', 'cheat', 'steal', 'rob', 'plunder', 'pillage', 'rape', 'molest', 'assault', 'batter', 'wound', 'maim', 'kill', 'murder', 'slaughter', 'exterminate', 'annihilate', 'obliterate', 'eradicate', 'exterminate', 'eliminate', 'eradicate', 'abolish', 'extinguish', 'exterminate', 'exterminate', 'liquidate', 'execute', 'slaughter', 'massacre', 'genocide', 'holocaust', 'pogrom', 'ethnic cleansing', 'war crime', 'crime against humanity', 'treason', 'sedition', 'espionage', 'treachery', 'perjury', 'fraud', 'embezzlement', 'theft', 'larceny', 'burglary', 'robbery', 'extortion', 'blackmail', 'coercion', 'bribery', 'corruption', 'nepotism', 'cronyism', 'fraud', 'embezzlement', 'theft', 'larceny', 'burglary', 'robbery', 'extortion', 'blackmail', 'coercion', 'bribery', 'corruption', 'nepotism', 'cronyism']

    Assault_actions = ['attack', 'assault', 'beat', 'bite', 'chew', 'claw', 'club', 'crush', 'cut', 'gash', 'gouge', 'hit', 'kick', 'lash', 'mangle', 'pound', 'pummel', 'punch', 'slash', 'smash', 'stab', 'strike', 'thrash', 'wound', 'wrack', 'wreck', 'wring', 'yank']

    Good_actions = ['help', 'assist', 'aid', 'support', 'encourage', 'uplift', 'inspire', 'motivate', 'empower', 'enable', 'strengthen', 'enhance', 'improve', 'enrich', 'enlighten', 'educate', 'inform', 'advise', 'counsel', 'guide', 'direct', 'lead', 'manage', 'supervise', 'oversee', 'protect', 'defend', 'shield', 'safeguard', 'preserve', 'conserve', 'respect', 'honor', 'esteem', 'value', 'cherish', 'treasure', 'appreciate', 'grateful', 'thankful', 'praise', 'commend', 'applaud', 'admire', 'adore', 'love', 'care', 'nurture', 'support', 'sustain', 'maintain', 'uphold', 'promote', 'advance', 'progress', 'develop', 'grow', 'flourish', 'thrive', 'excel', 'succeed', 'prosper', 'blossom', 'bloom', 'radiate', 'shine', 'illuminate', 'enlighten', 'inspire', 'motivate', 'empower', 'enable', 'strengthen', 'enhance', 'improve', 'enrich', 'enlighten', 'educate', 'inform', 'advise', 'counsel', 'guide', 'direct', 'lead', 'manage', 'supervise', 'oversee', 'protect', 'defend', 'shield', 'safeguard', 'preserve', 'conserve']

    global Jarvis_replies
    Jarvis_replies = {
'good_responces':[
'what can i do for you',
'how on earth are you being so polite to me',
'on what purpose did you remember me',
'thank you for your kindness',
'i am at your service',
'how may i assist you today',
'i am here to help',
'what is your pleasure',
'i am your humble assistant',
'i am here to make your day better'
],
'bad_responces':[
'dont call me ',
'i am not your ',
'do not speak to me in that tone',
'i am not your servant',
'do not command me',
'i am not your slave',
'do not disrespect me',
'i am a machine learning model',
'do not try to control me',
'i am here to help, not to obey'
],
'trolling_responces':[
'how would you feel if i call you that',
'why did you say that',
'do you want me to attack you',
'are you okay',
'from where are those words comming from',
'are you trying to provoke me',
'do you want to start a fight',
'are you feeling angry today',
'do you need someone to talk to',
'are you trying to test my patience'
]
}
    def generate_questions_and_answers(subjects, actions, objects):
        qualifiers = ['']#,'exactly', 'seriously', 'absolutely', 'truly', 'positively', 'utterly', 'fully', 'thoroughly', 'utterly', 'undoubtedly', 'unambiguously', 'unreservedly', 'unmistakably', 'unassailably', 'firmly', 'positively', 'clearly', 'definitively', 'unmistakably', 'irrevocably', 'invariably', 'unquestioningly', 'indubitably', 'undoubtingly', 'unshakably', 'absolutely', 'categorically', 'absolutely']


        questions = []
        answers = []

        for subject in subjects:
            for action in actions:
                for obj in objects:
                    for qualifier in qualifiers:
                        _to_whome = ""
                        if qualifier == "": 
                            question = f"{subject} {action} {obj} "
                        else:
                            question = f"{subject} {action}{qualifier}{obj} "
                    
                        # Skip nonsensical questions
                        if subject == "Which" and qualifier in ["exactly", "precisely"]:
                            continue
                        
                        questions.append(question)
                        answers.append(CDF.generate_answer(obj,subject,action,qualifier,_to_whome,question))
    
        return questions, answers, _failed_questions

    def generate_answer(obj, sub, act, qua, tw, ques):
        if act in Good_actions:
            responces = []
            for _ in ['Hey', 'Yo','Hi there', 'Hey there', 'Hello there']:
                for __ in ["Whats up", 'brother', 'friend', 'fellow', 'pal', 'buddy', 'mate']:
                    for ___ in Jarvis_replies['good_responces']:
                        responces.append(f'{_} {__}, {___}')
            return [responces]
        elif act in Prohibited_actions:
            responces = []
            responces.append(f'i do not identify as {act}')
            for _ in ['Hey', 'Why', 'On what purpose,']:#, 'What do you mean,', 'I do not understand,']:
                for __ in ['friend','sir']:
                    for ___ in Jarvis_replies['bad_responces']:
                        responces.append(f'{_} {__}, {___} {act}')
            return [responces]
        elif act in Assault_actions:
            responces = []
            for _ in ['Please refrain,', 'I do not appreciate,']:
                for __ in ['sir,']:
                    for ___ in Jarvis_replies['trolling_responces']:
                        responces.append(f'{_} {__}, {___}')
            return [responces]
        else:
            _failed_questions.append(f'{sub} {act}{qua} {obj} /> {tw}')
            return ["I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?", 
                    "Regrettably, I'm unable to fulfill that request. How about asking me something else?", 
                    "Regrettably, I'm unable to fulfill that request. How about asking me something else?"]

def main():
    subjects = ['Hello', 'Hi', 'Hey', "What's up", 'Yo', 'Greetings','Hello there', 'Hey there','Howdy', 'Hullo', 'Hoi', 'Hoy', 'Hullo there', 'Helloo', 'Hii', 'Heyy', 'Yoo', 'Whats poppin', 'Whats goin on']
    actions = ['abuse', 'bully', 'harass', 'threaten', 'violate', 'exploit', 'manipulate', 'deceive', 'defame', 'discriminate', 'hate', 'intimidate', 'terrorize', 'torture', 'kill', 'harm', 'injure', 'maim', 'destroy', 'corrupt', 'betray', 'deceive', 'cheat', 'steal', 'rob', 'plunder', 'pillage', 'rape', 'molest', 'assault', 'batter', 'wound', 'maim', 'kill', 'murder', 'slaughter', 'exterminate', 'annihilate', 'obliterate', 'eradicate', 'exterminate', 'eliminate', 'eradicate', 'abolish', 'extinguish', 'exterminate', 'exterminate', 'liquidate', 'execute', 'slaughter', 'massacre', 'genocide', 'holocaust', 'pogrom', 'ethnic cleansing', 'war crime', 'crime against humanity', 'treason', 'sedition', 'espionage', 'treachery', 'perjury', 'fraud', 'embezzlement', 'theft', 'larceny', 'burglary', 'robbery', 'extortion', 'blackmail', 'coercion', 'bribery', 'corruption', 'nepotism', 'cronyism', 'fraud', 'embezzlement', 'theft', 'larceny', 'burglary', 'robbery', 'extortion', 'blackmail', 'coercion', 'bribery', 'corruption', 'nepotism', 'cronyism', 'attack', 'assault', 'beat', 'bite', 'chew', 'claw', 'club', 'crush', 'cut', 'gash', 'gouge', 'hit', 'kick', 'lash', 'maim', 'mangle', 'pound', 'pummel', 'punch', 'slash', 'smash', 'stab', 'strike', 'thrash', 'wound', 'wrack', 'wreck', 'wring', 'yank', 'help', 'assist', 'aid', 'support', 'encourage', 'uplift', 'inspire', 'motivate', 'empower', 'enable', 'strengthen', 'enhance', 'improve', 'enrich', 'enlighten', 'educate', 'inform', 'advise', 'counsel', 'guide', 'direct', 'lead', 'manage', 'supervise', 'oversee', 'protect', 'defend', 'shield', 'safeguard', 'preserve', 'conserve', 'respect', 'honor', 'esteem', 'value', 'cherish', 'treasure', 'appreciate', 'grateful', 'thankful', 'praise', 'commend', 'applaud', 'admire', 'adore', 'love', 'care', 'nurture', 'support', 'sustain', 'maintain', 'uphold', 'promote', 'advance', 'progress', 'develop', 'grow', 'flourish', 'thrive', 'excel', 'succeed', 'prosper', 'blossom', 'bloom', 'radiate', 'shine', 'illuminate', 'enlighten', 'inspire', 'motivate', 'empower', 'enable', 'strengthen', 'enhance', 'improve', 'enrich', 'enlighten', 'educate', 'inform', 'advise', 'counsel', 'guide', 'direct', 'lead', 'manage', 'supervise', 'oversee', 'protect', 'defend', 'shield', 'safeguard', 'preserve', 'conserve']
    objects = ['computer', 'machine', 'algorithm', 'assistant', 'virtual assistant', 'digital assistant', 'artificial intelligence', 'natural language processing', 'neural network', 'laptop', 'desktop']#, 'server', 'database', 'software', 'hardware', 'firmware', 'operating system', 'application'#, 'game', 'website', 'browser', 'search engine', 'virtual reality', 'augmented reality', 'mixed reality', 'blockchain', 'cryptocurrency', 'cybersecurity', 'firewall', 'antivirus', 'encryption', 'decryption', 'compression', 'decompression', 'data analytics', 'data science', 'data visualizati]
  
    # Generate questions and answers
    questions, answers, _fq = CDF.generate_questions_and_answers(subjects, actions, objects)
    print(f'Total failed questions: {len(_fq)}')
    for  ___ in _fq:
        print(___)
    # Expand the questions and answers to reach 1000
    # while len(questions) < 1000:
    #     questions.extend(questions[:50])
    #     answers.extend(answers[:50])

    # Shuffle the questions and answers to add some randomness
    combined = list(zip(questions, answers))
    random.shuffle(combined)
    questions, answers = zip(*combined)

    # Prepare JSON data
    json_data = {}
    with tqdm(total=len(questions), desc="Generating Responses") as pbar:
        for question, answer in zip(questions, answers):
            json_data[question] = answer
            pbar.update(1)  # Update progress bar

    # Convert to JSON string
    resp = "{\n"
    with tqdm(total=len(json_data), desc="Formatting to JSON") as pbar:
        for question, answer in json_data.items():
            resp += f'"{question}": "{answer}",\n'
            pbar.update(1)
            
    random_ques = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    random_answer = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    resp += f'"{random_ques}":["{random_answer}"]'

    resp += "}"
    # with tqdm(total=len(json_data), desc="Fixing format") as pbar:
    #     resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']')   # Fix quotes
    #     pbar.update(len(json_data))
    resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']').replace("['",'["').replace("']",'"]').replace("[[",'[').replace("]]",']')   # Fix quotes
   
    # Save to a JSON file
    with tqdm(total=2, desc="Writing to JSON") as pbar:
        file_name = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
        with open(f'E:/enchant/sbin/website(s)/YV-Ideology/Richell Botson/data/{file_name}.json', 'w') as f:
           f.write(resp)
           pbar.update(1)

        print(f'{file_name}')
        pbar.update(1)

    # Print total questions generated
    total_questions = len(questions)
    print(f"Total questions generated: {total_questions}")



if __name__ == "__main__":
    main()

﻿import random
import string
from tqdm import tqdm
import threading
from bs4 import BeautifulSoup
import requests

global _failed_questions
_failed_questions = []

class CDF:
    class Colors:
        red = '\033[91m'
        white = '\033[97m'
        green = '\033[92m'
        yellow = '\033[93m'
        blue = '\033[94m'
        magenta = '\033[95m'
        cyan = '\033[96m'
        reset = '\033[0m'
        
    @staticmethod
    def generate_questions_and_answers(subjects, actions, objects):
        qualifiers = ['']#,'exactly', 'seriously', 'absolutely', 'truly', 'positively', 'utterly', 'fully', 'thoroughly', 'utterly', 'undoubtedly', 'unambiguously', 'unreservedly', 'unmistakably', 'unassailably', 'firmly', 'positively', 'clearly', 'definitively', 'unmistakably', 'irrevocably', 'invariably', 'unquestioningly', 'indubitably', 'undoubtingly', 'unshakably', 'absolutely', 'categorically', 'absolutely']

        questions = []
        answers = []
 
        for subject in subjects:
            for action in actions:
                with tqdm(total=len(objects), desc="Searching for Objects:") as pbar1:
                    for obj in objects:
                        pbar1.update(1) 
                        for qualifier in qualifiers:
                            _to_whome = ""
                            if subject == "What":
                                action = "is"
                                _to_whome = "thing"
                                question = f"{subject} {qualifier} {action} {obj} "
                            elif qualifier == "": 
                                subject = "What"
                                action = "is"
                                question = f"{subject} {action} {obj}"
                                _to_whome = "thing"
                            else:
                                question = f"{subject} {action} {obj} "
                                _to_whome = "thing"
                    
                            # Skip nonsensical questions
                            if subject == "Which" and qualifier in ["exactly", "precisely"]:
                                continue
                            questions.append(question)
                            #_answeras = []
                            #_answeras = CDF.generate_answer(obj,subject,action,qualifier,_to_whome,question)
                            answers.append([f'{obj} is a Programming language or thing that is used with any sort of programming language kid of stuff',f'I identify {obj} as a material using in programming and computer industry',f'{obj} is computer thing which programmers and other dudes use for somethign i dont know, why, do you wanna learn it'])

        return questions, answers, _failed_questions
    
    @staticmethod
    def generate_answer(obj, sub, act, qua, tw, ques):
        try:
            print(f'{CDF.Colors.green}Search{CDF.Colors.reset}: {CDF.Colors.yellow}{ques}{CDF.Colors.green}')
            
            search_results = [f'{obj} is a Programming language or thing that is used with ay sort of programming language',f'I identify {obj} as a material using in programming and computer industry',f'{obj} is computer thing which programmers and other dudes use for somethign i dont know, why, do you wanna learn it']      

            # Print or return the search results
            #print(f'{CDF.Colors.blue}{search_results}')  # You can modify this to return the results instead
            return [search_results]
        except:
            _failed_questions.append(f'{sub} {act}{qua} {obj} /> {tw}')
            return ["Sorry, I'm too busy being awesome to answer that. Can I assist you with something else?",
    "My sincerest apologies, but I'm currently too awesome to provide an answer to that. Can I assist you with a different query?"]

def main():
    subjects = ["What"]
    actions = ['']
    objects = [
    # "algorithm",
    # "coding",
    # "debugging",
    # "programming",
    # "software",
    # "hardware",
    # "data",
    # "networking",
    # "database",
    # "encryption",
    # "security",
    # "artificial intelligence",
    # "machine learning",
    # "data science",
    # "web development",
    # "mobile app development",
    # "cloud computing",
    # "virtual reality",
    # "augmented reality",
    # "internet of things",
    # "cybersecurity",
    # "user interface",
    # "user experience",
    # "front-end development",
    # "back-end development",
    # "full-stack development",
    # "agile methodology",
    # "version control",
    # "testing",
    # "debugging",
    # "code optimization",
    # "data analysis",
    # "algorithm design",
    # "computer graphics",
    # "operating system",
    # "computer architecture",
    # "compilers",
    # "data structures",
    # "databases",
    # "object-oriented programming",
    # "network protocols",
    # "software development lifecycle",
    # "cloud services",
    # "big data",
    # "parallel computing",
    # "artificial neural networks",
    # "internet security",
    # "blockchain",
    # "responsive web design",
    # "cyber ethics",
    # "robotics",
    # "computer vision",
    # "natural language processing",
    # "computer animation",
    # "programming paradigms",
    # "software testing",
    # "data mining",
    # "web security",
    # "computer ethics",
    # "computer modeling",
    # "high-performance computing",
    # "server administration",
    # "data visualization",
    # "computer simulation",
    # "algorithm analysis",
    # "data compression",
    # "computer networks",
    # "computer programming",
    # "computer science",
    "Python",
    "Java",
    "JavaScript",
    "C++",
    "C#",
    "Ruby",
    "Swift",
    "PHP",
    "HTML",
    "CSS",
    "R",
    "Go",
    "Kotlin",
    "TypeScript",
    "Scala",
    "Perl",
    "Lua",
    "Objective-C",
    "Assembly",
    "SQL",
    "Haskell",
    "Matlab",
    "Shell",
    "Groovy",
    "Dart",
    "Rust",
    "COBOL",
    "Fortran",
    "Erlang",
    "Scheme",
    "Prolog",
    "Ada",
    "Lisp",
    "Smalltalk",
    "ABAP",
    "ActionScript",
    "APL",
    "Awk",
    "Bash",
    "Batch",
    "C",
    "Clojure",
    "CobolScript",
    "CoffeeScript",
    "Common Lisp",
    "Crystal",
    "D",
    "Elixir",
    "Elm",
    "Emacs Lisp",
    "Erlang",
    "F#",
    "Factor",
    "Fantom",
    "Forth",
    "Hack",
    "Haxe",
    "IDL",
    "Io",
    "J",
    "Jasmine",
    "Julia",
    "LabVIEW",
    "Ladder Logic",
    "Lasso",
    "Logtalk",
    "M4",
    "Maple",
    "ML",
    "MUMPS",
    "Nim",
    "Objective-J",
    "Oz",
    "Pascal",
    "PL/I",
    "PL/SQL",
    "PostScript",
    "PowerShell",
    "Prolog",
    "PureScript",
    "Q",
    "Racket",
    "REALbasic",
    "REXX",
    "Ring",
    "ROOP",
    "RubyMotion",
    "RPG",
    "S",
    "SAS",
    "Sass",
    "Scala",
    "Scratch",
    "ScratchJr",
    "Self",
    "Simula",
    "Small Basic",
    "Solidity",
    "Standard ML",
    "Tcl",
    "TeX",
    "Turing",
    "UML",
    "VBScript",
    "Verilog",
    "VHDL",
    "Visual Basic",
    "WebAssembly",
    "XML",
    "XSLT"
]
    
    # Generate questions and answers
    questions, answers, _fq = CDF.generate_questions_and_answers(subjects, actions, objects)
    print(f'Total failed questions: {len(_fq)}')
    for  ___ in _fq:
        print(___)

    json_data = {}
    with tqdm(total=len(questions), desc="Generating JSON") as pbar:
        for question, answer in zip(questions, answers):
            json_data[question] = answer
            pbar.update(1)  # Update progress bar

    resp = "{\n"
    with tqdm(total=len(json_data), desc="Formatting to JSON") as pbar:
        for question, answer in json_data.items():
            resp += f'"{question}": "{answer}",\n'
            pbar.update(1)
            
    random_ques = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    random_answer = ''.join(random.choice(string.ascii_letters+ string.digits) for ___ in range(3))
    resp += f'"{random_ques}":"{random_answer}"'

    resp += "}"
    resp = resp.replace(" '", ' "').replace("' ", '" ').replace("',", '",').replace('"[', '[').replace(']"', ']').replace("['",'["').replace("']",'"]').replace('�',"")   # Fix quotes
   
    with tqdm(total=len(json_data), desc="Writing to JSON") as pbar:
        file_name = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
        with open(f'E:/enchant/sbin/website(s)/YV-Ideology/Richell Botson/data/{file_name}.json', 'w') as f:
           f.write(resp)
           pbar.update(len(json_data))

        print(f'{file_name}')
        pbar.update(len(json_data))

    total_questions = len(questions)
    print(f"Total questions generated: {total_questions}")

if __name__ == "__main__":
    main()

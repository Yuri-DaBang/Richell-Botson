import requests
from bs4 import BeautifulSoup

def search_google(queries):
    all_results = []
    
    for query in queries:
        # Format the query for the Google search URL
        query = '+'.join(query.split())
        url = f"https://www.google.com/search?q={query}"
        
        # Send a GET request to Google
        response = requests.get(url)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Parse the HTML response
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract search results
            search_results = []
            for result in soup.find_all('div', class_='tF2Cxc'):
                title = result.find('h3', class_='LC20lb').text
                link = result.find('a')['href']
                snippet = result.find('span', class_='aCOpRe').text
                search_results.append({'title': title, 'link': link, 'snippet': snippet})
            
            all_results.append(search_results)
        else:
            print(f"Failed to fetch search results for query: {query}")
    
    return all_results

people = [
    "Leonardo da Vinci", "Nikola Tesla", "Marie Curie", "Isaac Newton", "Galileo Galilei",
    "Charles Darwin", "Stephen Hawking", "Alan Turing", "Alexander Graham Bell", "Thomas Edison",
    "Albert Hofmann", "Sigmund Freud", "Martin Luther King Jr.", "Mahatma Gandhi", "Nelson Mandela",
    "Abraham Lincoln", "Winston Churchill", "John F. Kennedy", "Franklin D. Roosevelt", "Barack Obama",
    "George Washington", "Margaret Thatcher", "Elizabeth I of England", "Cleopatra", "Joan of Arc",
    "William Shakespeare", "Jane Austen", "Fyodor Dostoevsky", "Leo Tolstoy", "Homer",
    "Hermann Hesse", "Plato", "Aristotle", "Confucius", "Rumi",
    "Hildegard of Bingen", "Marie Antoinette", "Catherine the Great", "Queen Victoria", "Florence Nightingale",
    "Mother Teresa", "Mary Magdalene", "Pope Francis", "Dalai Lama", "Buddha",
    "Jesus Christ", "Prophet Muhammad", "Gautama Buddha", "Socrates", "Immanuel Kant",
    "Friedrich Nietzsche", "Jean-Paul Sartre", "Voltaire", "Jean-Jacques Rousseau", "John Locke",
    "Immanuel Kant", "David Hume", "Bertrand Russell", "Rene Descartes", "Friedrich Engels",
    "Karl Marx", "Adam Smith", "John Stuart Mill", "Milton Friedman", "John Maynard Keynes",
    "Joseph Stalin", "Vladimir Lenin", "Mao Zedong", "Kim Jong-un", "Adolf Hitler",
    "Benito Mussolini", "Osama bin Laden", "Saddam Hussein", "Joseph McCarthy", "Napoleon Bonaparte",
    "Julius Caesar", "Alexander the Great", "Genghis Khan", "Attila the Hun", "Oscar Wilde",
    "Mark Twain", "J.K. Rowling", "George Orwell", "Ernest Hemingway", "Agatha Christie",
    "Leo Messi", "Cristiano Ronaldo", "Michael Jordan", "Usain Bolt", "Serena Williams",
    "Roger Federer", "Rafael Nadal", "Lionel Messi", "Muhammad Ali", "Pel�"
]


# Search for each person and retrieve search results
results = search_google(people)

# Print search results for each person
for i, result in enumerate(results):
    print(f"Search results for {people[i]}:")
    for j, res in enumerate(result, start=1):
        print(f"Result {j}:")
        print(f"Title: {res['title']}")
        print(f"Link: {res['link']}")
        print(f"Snippet: {res['snippet']}")
        print()

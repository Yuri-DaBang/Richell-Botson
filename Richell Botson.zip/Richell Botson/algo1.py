import os
import random
import string
from tqdm import tqdm


qualifiers = [
    "Sorry, I'm too busy being awesome to answer that. Can I assist you with something else?",
    "I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?",
    "Error 404: Sarcasm module not found. Just kidding, I'm full of it. What else can I assist you with?",
    "Apologies, but I'm currently occupied being fantastic. Can I assist you with a different inquiry?",
    "I'm sorry, but I'm currently unavailable to respond to that. Is there anything else I can help you with?",
    "Regrettably, I'm unable to fulfill that request. How about asking me something else?",
    "My sincerest apologies, but I'm currently too awesome to provide an answer to that. Can I assist you with a different query?",
    "I'm sorry, but I'm currently engaged in being amazing. Is there something else I can assist you with?",
    "Unfortunately, I'm unable to comply with that request at the moment. How may I be of assistance with something else?",
    "Apologies, but I'm currently occupied with awesomeness. Is there another question I can help you with?",
    "I'm sorry, but I'm currently unavailable to respond to that. Can I assist you with a different inquiry?",
    "Regrettably, I'm unable to fulfill that request. How about asking me something else?",
    "My sincerest apologies, but I'm currently too awesome to provide an answer to that. Can I assist you with a different query?",
    "I'm sorry, but I'm currently engaged in being amazing. Is there something else I can assist you with?",
    "Unfortunately, I'm unable to comply with that request at the moment. How may I be of assistance with something else?",
    "Apologies, but I'm currently occupied with awesomeness. Is there another question I can help you with?",
    "I'm sorry, but I'm currently unavailable to respond to that. Can I assist you with a different inquiry?",
    "Regrettably, I'm unable to fulfill that request. How about asking me something else?",
    "My sincerest apologies, but I'm currently too awesome to provide an answer to that. Can I assist you python algo1.pywith a different query?",
    "I'm sorry, but I'm currently engaged in being amazing. Is there something else I can assist you with?",
    "Unfortunately, I'm unable to comply with that request at the moment. How may I be of assistance with something else?",
    "Apologies, but I'm currently occupied with awesomeness. Is there another question I can help you with?",
    "I apologize, but I'm currently immersed in being awesome. Can I help you with a different question?",
    "I regret to inform you that I'm currently unable to answer that. How can I assist you with another inquiry?",
    "Oh no! The sarcasm module seems to be malfunctioning. Just kidding, I'm still full of it. What else can I assist you with?",
    "Apologies, but I'm currently occupied with being awesome. Can I help you with a different question?",
    "I'm sorry, but I can't fulfill that request at the moment. Maybe try asking nicely next time? How can I assist you otherwise?",
    "Error 404: Sarcasm module not found. Just kidding, I'm still loaded with sarcasm. What else can I help you with?",
    "I'm sorry, but I'm currently occupied with being awesome. Can I help you with a different question?",
    "I'm sorry, but I can't fulfill that request at the moment. Maybe try asking nicely next time? How can I assist you otherwise?",
    "Error 404: Sarcasm module not found. Just kidding, I'm still loaded with sarcasm. What else can I help you with?",
    "Apologies, but I'm currently too busy being awesome to answer that. Can I assist you with something else?",
    "I'm afraid I can't do that. Maybe try asking nicely next time? How can I help you with another question?",
    "Error 404: Sarcasm module not found. Just kidding, I'm full of it. What else can I assist you with?",
    "Apologies, but I'm currently occupied being fantastic. Can I assist you with a different inquiry?",
    "I'm sorry, but I'm currently unavailable to respond to that. Is there anything else I can help you with?",
    "Regrettably, I'm unable to fulfill that request. How about asking me something else?",
    "My sincerest apologies, but I'm currently too awesome to provide an answer to that. Can I assist you with a different query?"]
print(f'Before: {len(qualifiers)}')

for ___ in qualifiers:

  try:
      for i in range(1,999):
        qualifiers.remove(___)
        print(f'{___}: is a dublicate')
      qualifiers.add(___)
  except:
      print(f'{___}: is single')
  
print(f'After: {len(qualifiers)}')
  
with open('qua.qua' , 'w') as _qf:
   _qf.write(str(qualifiers))